#include <stdio.h>
#include <stdlib.h>

void print_binary(int num)
{
    int i,mask=0x80000000;
    printf("The Binary Representation of number %d is : ",num);
    for(i=0;i<32;i++)
    {
        ((num<<i) & mask) ? printf("1"):printf("0");
    }
    printf("\n");
}

void print_number_of_ones_zeros(int num)
{
    int i,mask=0x80000000;
    int ones_count=0,zeros_count=0;
    for(i=0;i<32;i++)
    {
        ((num<<i) & mask) ? ++ones_count:++zeros_count;
    }
    printf("Number of ones inside the integer number %d is %d\n",num,ones_count);
    printf("Number of zeros inside the integer number %d is %d\n",num,zeros_count);
}

int main()
{
    int input;
    scanf("%d",&input);
    print_binary(input);
    print_number_of_ones_zeros(input);
    return 0;
}
