#include <stdio.h>
#include <stdlib.h>
typedef struct
{
  unsigned  widthValidated : 1;
  unsigned  heightValidated : 5;
} status;

typedef struct
{
  unsigned  widthValidated: 32;
  unsigned  heightValidated : 5;
  unsigned  longValidated : 3;
} status1;

int main()
{
    printf("%d %d",sizeof(status),sizeof(status1));
    return 0;
}
