#include <stdio.h>

#define MAX_SIZE 1024


/* Descrition:  A Macro used to check sum of the transmitted buffer of size MAX_SIZE
 *              after the receiver receive the transmitted data it checks if the sum
 *              of the data at the receiver equals to the sum of the transmitted data
 *              at the transmitter
 */


#define received_sum_Receiver(data_buffer,Size)\
	{\
		unsigned short transmitted_sum=0;\
		unsigned short received_sum=0;\
		int j;\
		\
		/* calculate the check sum at the receiver */ \
		for(j=0;j<Size-2;j++){\
			received_sum+=data_buffer[j];\
		}\
		printf("received_sum = %x\n",received_sum); \
		\
		/* get the transmitted sum from the buffer */ \
		transmitted_sum=(data_buffer[Size-1]<<(sizeof(data_buffer[Size-1])*8))+(data_buffer[Size-2]);\
		/* print it just for checl */ \
		printf("transmitted_sum = %x\n",transmitted_sum); \
		\
		/* check if the received received_sum == transmitted_sum */ \
		if(received_sum==transmitted_sum){\
			printf("Transmission Success");\
		}\
		else{\
			printf("Transmission fail");\
		}\
	}

int main(){
	int i;
	unsigned short check_sum=0;
	unsigned char data[MAX_SIZE];

	for(i=0;i<MAX_SIZE-2;i++){ // fill the buffer with ones except the last two bytes will include the sum of all data
		data[i]=1;
		check_sum=check_sum+data[i];
	}

	/* save the sum of all data in the last 2 bytes of the buffer */
	data[MAX_SIZE-2]=(unsigned char)check_sum; //save the least 8-bits in data[MAX_SIZE-2]
	data[MAX_SIZE-1]=check_sum>>(sizeof(data[MAX_SIZE-1])*8); //save the most 8-bits in data[MAX_SIZE-1]
	printf("check_sum = %x \t data[MAX_SIZE-2] = %x \t data[MAX_SIZE-1] = %x\n",check_sum,data[MAX_SIZE-2],data[MAX_SIZE-1]);

	/* data will be transmitted and we will check sum at the receiver */
    received_sum_Receiver(data,MAX_SIZE);

	return 0;
}
