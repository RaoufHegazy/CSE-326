/*
 * Common_Macros.h
 *
 * Created: 4/2/2014 7:47:21 PM
 *  Author: mohamed tarek 
 */ 


#ifndef COMMON_MACROS_H_
#define COMMON_MACROS_H_

#define SET_BIT(REG,BIT) (REG |= (1<<BIT))
#define CLEAR_BIT(REG,BIT) (REG &= ~(1<<BIT))


#endif /* COMMON_MACROS_H_ */