/*
 * Keypad.h
 *
 * Created: 4/3/2014 3:02:56 PM
 *  Author: mohamed tarek
 */ 


#ifndef KEYPAD_H_
#define KEYPAD_H_

#define N_col 4
#define N_row 4

#define KEYPAD_PORT_OUT PORTA
#define KEYPAD_PORT_IN  PINA
#define KEYPAD_PORT_DIR DDRA 

unsigned char KeyPad_Get_Pressed_Key(void);
unsigned char Adjust_Number_4x4_Keypad(unsigned char button_number);





#endif /* KEYPAD_H_ */