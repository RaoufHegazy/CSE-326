/*
 * Keypad_LCD.c
 *
 * Created: 4/2/2014 7:42:04 PM
 *  Author: mohamed tarek
 */ 

#include "LCD.h"
#include "Keypad.h"
#include<util/delay.h>

int main(void)
{
	unsigned char Key;
	LCD_Init();
    while(1)
    {
		/* if any switch pressed for more than 500 ms it counts more than one press */  
		Key=KeyPad_Get_Pressed_Key(); //get the pressed key number
		LCD_DisplayCharacter(Key); //display the pressed keypad switch 
		_delay_ms(500);
    }
}