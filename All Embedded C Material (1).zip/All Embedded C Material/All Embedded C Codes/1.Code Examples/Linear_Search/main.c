#include <stdio.h>
#define size 10
int Linear_Search(int array[],int element,int n); //Function Prototype

int main( void )
{
    int i;
    int array[size];
    int location;
    int element;
    printf("enter the required array: \n");
    for(i=0;i<size;i++){
        scanf("%d",&array[i]);
    }
    printf("enter element for search: ");
    scanf("%d",&element);
    location=Linear_Search(array,element,size);
    if(location==-1){
        printf("\nelement not found\n");
    }
    else {
        printf("\nthe element at the location: %d",location);
    }
    return 0;

}

int Linear_Search(int array[],int element,int n){
    int i;
    for(i=0;i<n;i++){
        if(element==array[i])
            return (i);
    }
    return -1; //element not found
}
