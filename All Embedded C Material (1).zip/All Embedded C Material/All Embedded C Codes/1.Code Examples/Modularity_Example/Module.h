/* function add two integer values */
int add(int,int);

/* function subtract two integer values */
int sub(int,int);

/* function multiply two integer values */
int mul(int,int);

/* function div two integer values
   it is a static function can't be used in
   another c files */
static int division(int,int);
