#include <stdio.h>
#include "Module.h"

int main()
{
    printf("%d",add(2,3));
    return 0;
}
