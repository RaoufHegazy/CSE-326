#include <stdio.h>
#include <stdlib.h>

#include "Module.h"
int add(int a,int b){
	return a+b;
}

int sub(int a,int b){
	return a-b;
}

int mul(int a, int b){
	return a*b;
}

int division(int a,int b){
	return a/b;
}

int main()
{
    int result;
    int (*ptr_func)(int,int) = add; //make pointer points to the add dunction
    result = (*ptr_func)(3,2); // call add function using pointer which points to it
    printf("result=%d\n",result);
    return 0;
}
