#include <stdio.h>
#include <stdlib.h>

int add(int a,int b){
	return a+b;
}

int sub(int a,int b){
	return a-b;
}

int mul(int a, int b){
	return a*b;
}

int division(int a,int b){
	return a/b;
}

int operation(int (*ptr_func)(int,int),int a,int b)
{
    return (*ptr_func)(a,b);
}

int main()
{
    int x=10,y=5;
    int result;
    result = operation(sub,x,y);
    printf("result=%d\n",result);
    return 0;
}
