/*
 * SW_timeout.c
 *
 * Created: 2/15/2014 6:35:46 PM
 * Author: Mohamed Tarek
 * Description: just to know how to make Software time out for any function. the user required to enter a char data 
 *				before the allowed time is expire.
 */ 

#ifndef F_CPU
#define F_CPU 8000000UL // or whatever may be your frequency
#endif

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#define NUMBER_OVF_PER_SECOND 31

/* tick is used for count the number of overflows of the timer i make tick variable long because for every second 
   the timer should overflow 31 times so for 10 seconds delay the timer should overflow 310 times. if i make 
   it unsigned char it will exceed its maximum value which is 255 */ 
unsigned long tick=0; //Global variable 

/**************************************************Timer Driver*************************************************/

void Timer_init(void){
	
	TCCR0=0b10000101; //prescalar = F_CPU/1024
	TCNT0=0;
	TIMSK=(1<<TOIE0); //enable overflow interrupt

}

void Timer_stop(void){
	
	TCCR0=0;
	TIMSK=0;
	
}

ISR(TIMER0_OVF_vect){ //timer overflow generate interrupt
	
	tick++;
	
}

/****************************************************************************************************************/

/**************************************************UART Driver**************************************************/
void USART_init(){
	
	UCSRA=(1<<U2X); //double transmission speed
	
	UCSRB=(1<<RXEN) | (1<<TXEN); //enable UART as transmitter and receiver.
	
	UCSRC=(1<<URSEL) |(1<<UCSZ0) | (1<<UCSZ1); //8-bit data, NO parity, one stop bit and asynch 
	
	/* baud rate=9600 & Fosc=8MHz -->  UBBR=103 for equation*/  
	UBRRH=0;
	UBRRL=103;
	
}

void USART_send(unsigned char data){
	
	while(!(UCSRA & (1<<UDRE))){} //UDRE flag is set when the buffer is empty and ready for transmitting a new byte.
	
	UDR=data;
	
}

unsigned char USART_recieve(unsigned char expire_time){
	
	Timer_init(); //start timer
	
	/*if the user don't enter data at the required time --> quit */
	while ( (!(UCSRA & (1<<RXC))) && (tick<=NUMBER_OVF_PER_SECOND*expire_time) ){} 
    
	Timer_stop(); //stop timer
	tick=0;
	
	return UDR;	
		
}

/***************************************************************************************************************/
	
int main(void)
{
	
	unsigned char var; 
	unsigned char expire_time=5; //maximum time allowed for user to enter data
	
	sei(); //enable interrupts
	USART_init();
	
	var=USART_recieve(expire_time);
	USART_send(var);
	
}