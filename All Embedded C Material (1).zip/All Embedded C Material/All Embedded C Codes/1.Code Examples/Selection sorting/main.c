#include <stdio.h>
#define arr_size 5

void swap(int *num1, int *num2)
{
    int temp;
    temp = *num1;
    *num1 = *num2;
    *num2 = temp;
}
void selection_sorting(int array[],const int size){
    int i,j,min;
    for(i=0;i<size-1;i++){
        min=i;
        for(j=i+1;j<size;j++){
            if(array[min]>array[j])
                min=j;
        }
        swap(&array[min],&array[i]);
    }
}
int main()
{
    int arr[arr_size],i;
    printf("Enter the required numbers to be sorted:\n");
    for(i=0;i<arr_size;i++){
        scanf("%d",&arr[i]);
    }
    selection_sorting(arr,arr_size);
    printf("array after sorting:\n");
    for(i=0;i<arr_size;i++){
        printf("%d  ",arr[i]);
    }
    return 0;
}
