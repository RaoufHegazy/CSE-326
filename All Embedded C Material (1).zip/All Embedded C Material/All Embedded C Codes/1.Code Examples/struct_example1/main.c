#include <stdio.h>

struct employee{
char *name;
float salary;
};

int main()
{
    struct employee emp1,emp2;
    struct employee *emp_ptr;

    emp1.name = "Mohamed";
    emp1.salary = 1000;
    printf("Print Employee 1 Info: \n");
    printf("%s \t %f \n",emp1.name,emp1.salary);

    /* Manipulate emp2 using pointer */
    emp_ptr = &emp2;
    emp_ptr->name = "Ahmed";
    emp_ptr->salary = 500;
    printf("Print Employee 2 Info using pointer: \n");
    printf("%s \t %f \n",emp_ptr->name,emp_ptr->salary);

    printf("Print Employee 2 Info: \n");
    printf("%s \t %f \n",emp2.name,emp2.salary);

    printf("Size of emp1 and emp2 objects = %d",sizeof(emp1));

    return 0;
}
