#include <stdio.h>

struct employee{
char *name;
float salary;
};

void modify_employee1(struct employee emp1)
{
    emp1.name = "Ahmed";
    emp1.salary = 500;
}

void modify_employee2(struct employee *emp2)
{
    emp2->name = "Ahmed";
    emp2->salary = 500;
}

int main()
{
    struct employee emp;

    emp.name = "Mohamed";
    emp.salary = 1000;
    modify_employee1(emp); //pass emp structure by value
    printf("%s \t %f \n",emp.name,emp.salary);
    modify_employee2(&emp); //pass emp structure by address
    printf("%s \t %f \n",emp.name,emp.salary);

    return 0;
}
