#include <stdio.h>

union Data
{
   int i;
   double f;
   char  *str;
};

int main( )
{
   union Data d1;

   d1.i = 10;
   d1.f = 220.5;
   d1.str = "C Programming";


   printf( "d1.i : %d\n", d1.i);
   printf( "d1.f : %lf\n", d1.f);
   printf( "d1.str : %s\n", d1.str);
   printf("Size of d1 object = %d bytes",sizeof(d1));

   return 0;
}
