/*
 * Keypad_LCD.c
 *
 * Created: 4/2/2014 7:42:04 PM
 *  Author: mohamed tarek
 */ 

#include "LCD.h"
#include "Keypad.h"

int main(void)
{
	unsigned char key;
	LCD_Init();
    while(1)
    {
		/* if any switch pressed for more than 500 ms it counts more than one press */  
		key=KeyPad_GetPressedKey(); //get the pressed key number
		if((key<=9) && (key>=0))
		{
			LCD_IntgerToString(key); //display the pressed keypad switch 
			_delay_ms(500);
		}
		else
		{
			LCD_DisplayCharacter(key); //display the pressed keypad switch 
			_delay_ms(500);
		}
    }
}