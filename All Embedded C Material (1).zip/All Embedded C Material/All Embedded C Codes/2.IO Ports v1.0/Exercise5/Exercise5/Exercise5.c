/*
 * Exercise5.c
 *
 * Created: 11/23/2013 1:36:59 AM
 *  Author: Mohamed Tarek
 */
 
#include <avr/io.h>

int main(void)
{
	
	DDRA = DDRA & (~(1<<PA0)); // configure pin 0 of PORTA as input pin
	DDRA = DDRA & (~(1<<PA1)); // configure pin 1 of PORTA as input pin
	DDRA = DDRA & (~(1<<PA2)); // configure pin 2 of PORTA as input pin
	DDRC = DDRC | (1<<PC0);    // configure pin 3 of PORTC as output pin
	DDRC = DDRC | (1<<PC1);    // configure pin 4 of PORTC as output pin
	
	//Motor is stop at the beginning
	PORTC = 0;
	 
    while(1)
    {
		// check if the first switch is pressed (Rotate clock wise)
		if(PINA & (1<<PA0))
		{
					PORTC = PORTC & (~(1<<PC0));
					PORTC = PORTC | (1<<PC1);
		}
		
		// check if the second switch is pressed (Rotate anti-clock wise)
		else if(PINA & (1<<PA1))
		{
					PORTC = PORTC | (1<<PC0);
					PORTC = PORTC & (~(1<<PC1));
			
		}		
		// check if the third switch is pressed (turn off the motor)
		else if(PINA & (1<<PA2))
		{
					PORTC = PORTC & (~(1<<PC0));
					PORTC = PORTC & (~(1<<PC1));
		}
							    
    }
}