/*
 * Exercise7.c
 *
 * Created: 4/3/2014 6:00:08 PM
 *  Author: mohamed tarek
 */ 

#include "LCD.h"

int main(void)
{
	
	LCD_Init(); //initialize LCD 
	LCD_DisplayString_XY(0,2,"My LCD Driver");
	LCD_DisplayString_XY(1,3,"Embedded WS");
	_delay_ms(2000); //wait two seconds
	
	LCD_ClearScreen(); //clear the LCD display 
	LCD_DisplayString("Interf. Course");
	
	/* Note: we write the code before while(1) because we want it to execute only once */
		
    while(1)
    {
		
    }
	
}