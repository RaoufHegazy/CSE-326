﻿/*
 * ADC.h
 *
 * Created: 24/04/2014 02:56:24 م
 *  Author: Mohamed Tarek
 */ 


#ifndef ADC_H_
#define ADC_H_

#include <avr/io.h>

void ADC_Init(void);
unsigned short ADC_Read(unsigned char channel_num);

#endif /* ADC_H_ */