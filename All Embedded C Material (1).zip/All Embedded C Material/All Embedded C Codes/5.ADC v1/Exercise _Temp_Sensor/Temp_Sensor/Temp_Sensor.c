﻿/*
 * Temp_Sensor.c
 *
 * Created: 24/04/2014 02:55:48 م
 *  Author: Mohamed Tarek
 */ 

#include "ADC.h"
#include "LCD.h"

int main(void)
{
	unsigned long temp;
	LCD_Init();
	ADC_Init();
	LCD_ClearScreen(); //clear LCD at the beginning
	LCD_DisplayString("Temp = ");
	LCD_GoTo_XY(0,10);
	LCD_DisplayCharacter('C');
    while(1)
    {
		LCD_GoTo_XY(0,7); //to display the number
		temp = ADC_Read(0); //Read channel zero where the temp sensor is connect
		temp = (temp*150*5)/(1023*1.5); //calculate the temp
		LCD_IntgerToString(temp); //display the temp on LCD screen 
    }
}