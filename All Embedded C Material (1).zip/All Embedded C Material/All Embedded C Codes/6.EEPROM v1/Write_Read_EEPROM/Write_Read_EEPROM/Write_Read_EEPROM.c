/*
 * Write_Read_EEPROM.c
 *
 * Created: 3/10/2014 11:50:16 PM
 *  Author: Mohamed Tarek
 */ 
#include <avr/eeprom.h>

int main(void)
{
	unsigned char ByteOfData;
	DDRD  = 0xFF;
	eeprom_write_byte((uint16_t*)0,0x02); //save data=0x02 to address 0
    ByteOfData = eeprom_read_byte((uint16_t*)0); //read data from address 0 
	PORTD = ByteOfData; //out data on PORTC
    while(1)
    {
         
    }
}