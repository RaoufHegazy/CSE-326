/*
 * MC1.c
 *
 * Created: 25/04/2014 11:09:26 �
 *  Author: Mohamed Tarek
 */ 

#include "Keypad.h"
#include "UART.h"
#include <util/delay.h>

int main(void)
{
	uint8 key;
	UART_Init();
    while(1)
    {
		key = KeyPad_GetPressedKey(); //get the pressed key
		UART_SendByte(key); //send the pressed key to the second MC using uart
		_delay_ms(500);
    }
}