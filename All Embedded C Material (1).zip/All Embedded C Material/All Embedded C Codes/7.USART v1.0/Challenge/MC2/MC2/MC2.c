/*
 * MC2.c
 *
 * Created: 25/04/2014 11:12:30 �
 *  Author: Mohamed Tarek
 */ 

#include "UART.h"
#include "LCD.h"

int main(void)
{
	uint8 key;
	UART_Init();
	LCD_Init();
    while(1)
    {
		key = UART_RecieveByte(); //receive the pressed key from uart
		if( (key >= 0) && (key <= 9) )
		{
			LCD_IntgerToString(key); //display the pressed keypad switch	
		}
		else
		{
			LCD_DisplayCharacter(key); //display the pressed keypad switch	
		}		 
    }
}