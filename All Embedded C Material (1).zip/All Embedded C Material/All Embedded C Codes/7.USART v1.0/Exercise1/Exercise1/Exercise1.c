/*
 * Exercise1.c
 *
 * Created: 4/10/2014 9:23:41 PM
 * Author: Mohamed Tarek
 */ 

#include "UART.h"

int main(void)
{
	char Str[20];
	char data;
	UART_Init();
    while(1)
    { 
		data = UART_RecieveByte(); //Receive Byte from Terminal1
		UART_SendByte(data); //Resend the received byte to Terminal2
		//UART_ReceiveString(Str); //Receive String from Terminal
		//UART_SendString(Str); //Resend the string to Terminal2
    }
}