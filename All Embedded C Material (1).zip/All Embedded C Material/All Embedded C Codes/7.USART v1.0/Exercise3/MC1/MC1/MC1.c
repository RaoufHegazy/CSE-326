/*
 * MC1.c
 *
 * Created: 4/10/2014 11:21:37 PM
 *  Author: mohamed tarek
 */ 

#include "UART.h"
#include <util/delay.h>

int main(void)
{
	UART_Init(); //initialize UART
	_delay_ms(30); //Wait until MC2 finisih its initialization
	UART_SendString("I am Micro1#"); //send the required string to MC2 
	
    while(1)
    {
		 
    }
}