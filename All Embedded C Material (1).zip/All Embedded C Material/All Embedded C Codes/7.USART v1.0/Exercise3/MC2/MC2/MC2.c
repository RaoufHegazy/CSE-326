/*
 * MC2.c
 *
 * Created: 4/10/2014 11:23:48 PM
 *  Author: mohamed tarek
 */ 

#include "UART.h"
#include "LCD.h"

int main(void)
{
	char Str[20];
	UART_Init();
	LCD_Init();
	UART_ReceiveString(Str); //receive the string 
	LCD_DisplayString(Str); //display the string in LCD
    while(1)
    {
		
    }
}