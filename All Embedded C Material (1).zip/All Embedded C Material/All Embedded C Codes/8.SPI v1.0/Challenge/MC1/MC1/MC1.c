﻿/*
 * MC1.c
 *
 * Created: 25/04/2014 11:30:09 م
 *  Author: Mohamed Tarek
 */ 

#include "Keypad.h"
#include "SPI.h"
#include <util/delay.h>

int main(void)
{
	char key;
	SPI_Init_Master();
    while(1)
    {
		key = KeyPad_GetPressedKey(); //get the pressed key
		SPI_Send_Byte(key); //send the pressed key to the second MC using spi
		_delay_ms(300); 	
    }
}