/*
 * SPI.c
 *
 * Created: 3/10/2014 9:30:41 PM
 *  Author: Mohamed Tarek
 */ 

#ifndef SPI_H_
#define SPI_H_

#include <avr/io.h>

void SPI_Init_Master(void); 
void SPI_Init_Slave(void);
void SPI_Send_Byte(char data); 
char SPI_Recieve_Byte(void);
void SPI_SendString(const char *Str);
void SPI_ReceiveString(char *Str);
#endif