﻿/*
 * MC2.c
 *
 * Created: 25/04/2014 11:32:23 م
 *  Author: Mohamed Tarek
 */ 

#include "SPI.h"
#include "LCD.h"

int main(void)
{
	char key;
	LCD_Init();
	SPI_Init_Slave();
    while(1)
    {
		key = SPI_Recieve_Byte();  //receive the pressed key from spi
		if((key>=0) && (key<=9))
		{
			LCD_IntgerToString(key); //display the pressed key
		}
		else
		{
			LCD_DisplayCharacter(key);
		}	
    }
}