﻿/*
 * MC1.c
 *
 * Created: 26/04/2014 12:34:54 ص
 *  Author: Mohamed Tarek
 */ 

#include "SPI.h"
#include <util/delay.h>

int main(void)
{
	SPI_Init_Master();
	_delay_ms(10); /* delay until MC2 finish its initialization task */
	SPI_SendString("I am Micro1#");
    while(1)
    {
		
    }
}