/*
 * SPI.c
 *
 * Created: 3/10/2014 9:30:29 PM
 * Author: Mohamed Tarek
 */

#include "SPI.h"

void SPI_Init_Master(void) 
{
	/******** Configure SPI Master Pins *********
	 * SS(PB4)   --> Output
	 * MOSI(PB5) --> Output 
	 * MISO(PB6) --> Input
	 * MOSI(PB7) --> Output
	 ********************************************/
	DDRB = DDRB | (1<<PB4);
	DDRB = DDRB | (1<<PB5);
	DDRB = DDRB & ~(1<<PB6);
	DDRB = DDRB | (1<<PB7);
	
	SPCR = (1<<SPE) | (1<<MSTR); // enable SPI + enable Master + choose SPI clock = Fosc/4
}

void SPI_Init_Slave(void)
{ 
	/******** Configure SPI Slave Pins *********
	 * SS(PB4)   --> Input
	 * MOSI(PB5) --> Input
	 * MISO(PB6) --> Output
	 * MOSI(PB7) --> Input
	 ********************************************/
	DDRB = DDRB & (~(1<<PB4));  
	DDRB = DDRB & (~(1<<PB5));
	DDRB = DDRB | (1<<PB6);
	DDRB = DDRB & (~(1<<PB7));
	SPCR = (1<<SPE); // just enable SPI 
}

void SPI_Send_Byte(const char data) 
{
	SPDR = data; //send data by SPI
	while((SPSR & (1<<SPIF)) == 0){} //wait until SPI interrupt flag=1 (data is sent correctly)								
}

char SPI_Recieve_Byte(void)
{
   while((SPSR & (1<<SPIF)) == 0){} //wait until SPI interrupt flag=1(data is receive correctly)	
   return SPDR; //return the received byte from SPI data register
}
void SPI_SendString(const char *Str){
	unsigned char i = 0;
	while(Str[i] != '\0')
	{
		SPI_Send_Byte(Str[i]);
		i++;
	}
}

void SPI_ReceiveString(char *Str)
{
	unsigned char i = 0;
	Str[i] = SPI_Recieve_Byte();
	while(Str[i] != '#')
	{
		i++;
		Str[i] = SPI_Recieve_Byte();
	}
	Str[i] = '\0';
}