﻿/*
 * MC2.c
 *
 * Created: 26/04/2014 12:38:59 ص
 *  Author: Mohamed Tarek
 */ 

#include "SPI.h"
#include "LCD.h"

int main(void)
{
	char str[20];
	LCD_Init();
	SPI_Init_Slave();
	SPI_ReceiveString(str);
	LCD_DisplayString(str);
    while(1)
    {
         
    }
}