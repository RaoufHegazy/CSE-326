/*
 * SPI_Test.c
 *
 * Created: 4/11/2014 8:20:28 PM
 *  Author: mohamed tarek
 */ 

#include "SPI.h"

#define SWITCH_PRESSED 1
#define SWITCH_NOT_PRESSED 0

int main(void)
{
	SPI_Init_Master();
	DDRA = DDRA & (~(1<<PA0)); //configure PA0 as input pin
    while(1)
    {
		if(PINA & (1<<PA0)) //if switch is pressed
		{
			SPI_Send_Byte(SWITCH_PRESSED);
		}
		else
		{
			SPI_Send_Byte(SWITCH_NOT_PRESSED);
		}						
    }
}